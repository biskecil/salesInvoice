<div class="card-header bg-white border-1 pb-2">
    <div class="d-flex gap-2 justify-content-between">
        <div class="d-flex flex-wrap gap-2">
            <button type="button" id="btnSubmitCreate" class="btn btn-warning btn-sm">
                <i class="fa-solid fa-save"></i> Simpan
            </button>
            <a type="button" class="btn btn-danger btn-sm" id="btnBatal" href="/grosir/show">
                <i class="fa-solid fa-xmark"></i> Batal
            </a>
        </div>
    </div>
</div>