require("./bootstrap");
import AutoNumeric from "autonumeric";

window.AutoNumeric = AutoNumeric;
