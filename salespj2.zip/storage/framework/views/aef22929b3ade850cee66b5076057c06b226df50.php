<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LMS - ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg-primary-color{
            background-color:#913030 !important;
        }
    </style>
</head>
<body class="bg-light">

    
    <div class="bg-primary-color text-white py-2 px-3 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <img src="<?php echo asset('assets/images/favicon.png'); ?>" 
                 class="w-px-40 h-auto rounded-circle me-2"
                 style="opacity:.9; width:50px; height:50px; object-fit:cover;">
            <span class="app-brand-text demo menu-text fw-bolder text-white">
                LMS - SALES
            </span>
        </div>
        
    </div>

    
    <nav class="navbar navbar-expand-lg bg-white shadow-sm py-1">
        <div class="container-fluid">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link text-secondary fw-semibold d-flex align-items-center" href="#">
                        <i class="bi bi-receipt me-2"></i> 
                        Nota Tagihan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-secondary fw-semibold d-flex align-items-center" href="#">
                        <i class="bi bi-receipt me-2"></i> 
                        Info Tagihan
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    
    <main class="container-fluid py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Wisnu\Coding\lmsales\resources\views/layouts/app.blade.php ENDPATH**/ ?>