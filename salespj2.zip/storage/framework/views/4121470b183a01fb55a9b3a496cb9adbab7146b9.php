

<?php $__env->startSection('content'); ?>
    <style>
        table input.form-control,
        table input.form-control-sm {
            margin: 0;
            /* hilangkan margin bawaan */
            padding: 0.25rem;
            /* bikin seragam */
            height: auto;
            /* biar tidak terlalu tinggi */
        }

        .summary-weight {
            font-weight: bold;
            color: #d9534f;
            font-size: 16px;
        }

        .myGrid .dx-datagrid-rowsview .dx-row>td {
            font-size: 16px;
            /* perbesar font */
            font-weight: normal;
        }

        /* Header column */
        .myGrid .dx-datagrid-headers .dx-header-row>td {
            font-size: 12px;
            font-weight: bold;
            color: #000000;
        }
    </style>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0 text-center fw-bold ">Form Grosir - Edit</h5>
                </div>
                <div class="card-body">
                    <div class="card card-main shadow-sm " id="formCard">
                        <?php echo $__env->make('grosir.action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card-body pt-0">
                            <!-- FORM UTAMA -->
                            <form action="/grosir/update" method="post" id="salesForm" class="mt-4">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <!-- LEFT -->
                                    <div class="col-md-8">
                                        <div class="mb-2 row">
                                            <label class="form-label col-sm-4">SW</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control d-none" value="<?php echo e($data->ID); ?>" name="id" placeholder="SW">
                                                <input type="text" class="form-control" value="<?php echo e($data->SW); ?>" name="sw" placeholder="SW">
                                            </div>
                                        </div>
                                        <div class="mb-2 row">
                                            <label class="form-label col-sm-4">Description</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" value="<?php echo e($data->Description); ?>" name="description"
                                                    placeholder="Description">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>




                <script src="<?php echo e(asset('jquery/jquery-3.6.0.min.js')); ?>"></script>
                <script>
                    $("#btnSubmitCreate").on("click", function(e) {
                        e.preventDefault(); // prevent normal form submit

                        $.ajax({
                            url: $("#salesForm").attr("action"),
                            type: "POST",
                            data: $("#salesForm").serialize(),
                            success: function(response) {
                                Swal.fire({
                                    title: "Berhasil",
                                    text: "Data telah berhasil disimpan.",
                                    icon: "success",
                                    confirmButtonText: "OK"
                                }).then((result) => {
                                    if (result.isConfirmed || result.isDismissed) {
                                        // window.location.href = '/sales/detail/' + response.data;
                                        window.location.reload();
                                    }
                                });
                            },
                            error: function(xhr) {
                                if (xhr.status === 422) {
                                    Swal.fire({
                                        title: "Gagal",
                                        text: xhr.responseJSON.message,
                                        icon: "error",
                                        confirmButtonText: "OK"
                                    });
                                } else {
                                    Swal.fire({
                                        title: "Gagal",
                                        text: "Server Error",
                                        icon: "error",
                                        confirmButtonText: "OK"
                                    });
                                }

                            }
                        });
                    });
                </script>
            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\salespj2\resources\views/grosir/edit.blade.php ENDPATH**/ ?>