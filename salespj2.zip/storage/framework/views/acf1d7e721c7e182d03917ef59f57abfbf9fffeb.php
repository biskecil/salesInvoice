<?php $__env->startSection('content'); ?>
<div class="row">
    
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm">
            <div class="card-header bg-white border-0">
                <ul class="nav nav-tabs card-header-tabs">
                    <li class="nav-item">
                        <a class="nav-link active text-danger fw-bold" href="#">Pengumuman</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Sudah Berakhir</a>
                    </li>
                </ul>
            </div>
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>TANGGAL</th>
                            <th>OLEH</th>
                            <th>NOTE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="3" class="text-center text-muted">No Data</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm">
            <div class="card-header bg-white border-0">
                <ul class="nav nav-tabs card-header-tabs">
                    <li class="nav-item"><a class="nav-link active text-danger fw-bold" href="#">Antrian</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Proses</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Tunda</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Selesai</a></li>
                </ul>
            </div>
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>NO.</th>
                            <th>TANGGAL</th>
                            <th>TODO</th>
                            <th>REMARKS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="4" class="text-center text-muted">No Data</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<div class="mt-3">
    <h6 class="fw-bold">Recap Absensi IT August 2025</h6>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\salespj\resources\views/info_tagihan.blade.php ENDPATH**/ ?>