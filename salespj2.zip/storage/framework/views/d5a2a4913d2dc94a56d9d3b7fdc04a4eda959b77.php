

<?php $__env->startSection('content'); ?>
    <style>
        table input.form-control,
        table input.form-control-sm {
            margin: 0;
            /* hilangkan margin bawaan */
            padding: 0.25rem;
            /* bikin seragam */
            height: auto;
            /* biar tidak terlalu tinggi */
        }
    </style>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <?php echo $__env->make('layouts-client.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card-body pt-0">

                </div>
            </div>
        </div>
    </div>




    <script src="<?php echo e(asset('jquery/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('jquery-ui/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('select2/select2.min.js')); ?>"></script>
    <script src="<?php echo asset('timbangan/timbangan.js'); ?>"></script>

    <script>
        window.addEventListener("load", () => {
            connectSerial(true);
        });

        $(document).ready(function() {
            let dataNota = '';
            $('#btnTambah').prop('disabled', false);
            $('#btnBatal').prop('disabled', true);
            $('#btnCetakParent').prop('disabled', true);
            $('#btnCetakBarcode').prop('disabled', true);
            $('#btnEdit').prop('disabled', true);
            $('.buttonForm').prop('disabled', true).hide();

            $('#cariDataNota').on('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    $('#btnCari').click();
                }
            });

            $('#btnCari').on('click', function() {
                dataNota = $('#cariDataNota').val();
                if (dataNota == '') {
                    dataNota = 0;
                }


                $.ajax({
                    url: '/sales/detail/' + dataNota,
                    method: 'GET',
                    success: function(response) {
                        window.location.href = '/sales/detail/' + dataNota;
                    },
                    error: function(xhr) {
                        if (xhr.status === 500) {

                            Swal.fire({
                                title: "Info",
                                text: "Data tidak ditemukan",
                                icon: "warning",
                                confirmButtonText: "OK"
                            });
                        }
                    }
                });

            });

            $('#btnTambah').on('click', function() {
                window.location.href = '/sales/create';
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-client.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\salespj2\resources\views/invoice/form.blade.php ENDPATH**/ ?>