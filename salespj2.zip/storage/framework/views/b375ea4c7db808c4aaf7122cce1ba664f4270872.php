<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Label Customer</title>
    <style>
        @page  {
            size: 100mm 50mm;
            margin: 0;
        }

        body {
            font-family: Arial, sans-serif;
            /* font-weight: bold; */
            font-size: 16px;
            padding-left: 15px;
            padding-top: 16px;
        }

        /* body {
            font-family: Arial, sans-serif;
            font-size: 10px;
            margin: 0;
            padding: 0;
        }

      


        .kode2 {
            font-size: 21px;
            font-weight: bold;
            margin-top: 3px;
        } */
    </style>
</head>

<body>
    <table style="width:100%; " border="0">
        <tr>
            <td style="text-align:left;font-weight: bold;font-size:28px;">LG</td>
            <td style="text-align:left;font-size:20px;" rowspan="2">Berat&nbsp;: <b><?php echo e($data->wbruto_form); ?></b>
            </td>
        </tr>
        <tr>
            <td style="text-align:left;">Grosir&nbsp;: <?php echo e($data->Grosir); ?></td>

        </tr>
        <tr>
            <td style="text-align:left;">Ket&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo e($data->noNota); ?></td>
            <td style="text-align:left;">Kadar&nbsp;&nbsp;: <b><?php echo e($data->carat); ?></b></td>
        </tr>
        <tr>
            <td style="text-align:left;">&nbsp;</td>

        </tr>
       
        <tr>
            <td colspan="2" style="text-align:center; font-size:25px; vertical-align:bottom;">
                <?php echo e($data->Customer); ?><br>
                <p style="font-size:15px; margin:0; line-height:18px;"><i><?php echo e($data->Address); ?></i></p>
            </td>
        </tr>

    </table>

</body>



</html>
<?php /**PATH D:\salespj2\resources\views/pack/cetakPack.blade.php ENDPATH**/ ?>