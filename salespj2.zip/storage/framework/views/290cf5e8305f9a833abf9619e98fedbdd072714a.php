

<?php $__env->startSection('content'); ?>
    <style>
        table input.form-control,
        table input.form-control-sm {
            margin: 0;
            /* hilangkan margin bawaan */
            padding: 0.25rem;
            /* bikin seragam */
            height: auto;
            /* biar tidak terlalu tinggi */
        }
    </style>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0 text-center fw-bold ">List Invoice</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered mb-0" id="itemsTable">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 120px;">No</th>
                                <th style="width: 150px;">Nota</th>
                                <th style="width: 150px;">Grosir</th>
                                <th style="width: 150px;">Customer</th>
                                <th style="width: 150px;">Address</th>
                                <th style="width: 150px;">Phone</th>
                                <th style="width: 150px;">Kategori</th>
                                <th style="width: 150px;">Kadar</th>
                                <th style="width: 150px;">Berat</th>
                                <th style="width: 150px;">Event</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>-</td>
                                <td><?php echo e($d->Grosir); ?></td>
                                <td><?php echo e($d->Customer); ?></td>
                                <td><?php echo e($d->Address); ?></td>
                                <td><?php echo e($d->Phone); ?></td>
                                <td><?php echo e($d->category_name); ?></td>
                                <td><?php echo e($d->carat_name); ?></td>
                                <td><?php echo e($d->Weight); ?></td>
                                <td><?php echo e($d->Event); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>




    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\salespj2\resources\views/invoice/show.blade.php ENDPATH**/ ?>