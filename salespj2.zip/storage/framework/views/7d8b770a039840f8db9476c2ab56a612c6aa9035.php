<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Label Customer</title>
    <style>
        @page  {
            size: 100mm 50mm;
            margin: 0;
        }

        body {
            font-family: Arial, sans-serif;
            font-weight: bold;
            font-size:16px;
            padding-left: 15px;
            padding-top: 16px;
        }

        /* body {
            font-family: Arial, sans-serif;
            font-size: 10px;
            margin: 0;
            padding: 0;
        }

      


        .kode2 {
            font-size: 21px;
            font-weight: bold;
            margin-top: 3px;
        } */
    </style>
</head>

<body>
    <table style="width:100%; " border="0">
        <tr>
            <td style="text-align:left;">Lestari</td>
            <td style="text-align:left;">Kadar&nbsp;: 16K</td>
        </tr>
        <tr>
            <td style="text-align:left;">Grosir&nbsp;: SA</td>
            <td style="text-align:left;">Berat&nbsp;&nbsp;: 175.56</td>
        </tr>
        <tr>
            <td style="text-align:left;">Ket&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: IIC19090001</td>

        </tr>
        <tr>
            <td style="text-align:left;">&nbsp;</td>

        </tr>
        <tr>
            <td colspan="2" style="text-align:center; font-size:25px; vertical-align:bottom;">
                Mahkota<br>
                <p style="font-size:15px; margin:0; line-height:18px;"><i>Surabaya</i></p>
            </td>
        </tr>

    </table>

</body>



</html>
<?php /**PATH D:\salespj2\resources\views/tes.blade.php ENDPATH**/ ?>