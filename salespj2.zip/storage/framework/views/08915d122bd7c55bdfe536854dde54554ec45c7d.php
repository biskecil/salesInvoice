<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card shadow-sm">
            <div class="card-header bg-white border-0">
                <h5 class="mb-0 text-center fw-bold ">Tambah Invoice</h5>
            </div>
            <div class="card-body">
                <!-- FORM UTAMA -->
<form action="/sales/create" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <!-- LEFT -->
        <div class="col-md-4">
            <div class="mb-3">
                <label class="form-label">Tanggal</label>
                <input type="date" class="form-control"  name="transDate">
            </div>
            <div class="mb-3">
                <label class="form-label">Customer</label>
                <input type="text" class="form-control" placeholder="Nama customer"  name="customer">
            </div>
            <div class="mb-3">
                <label class="form-label">Nama Pembeli</label>
                <input type="text" class="form-control" placeholder="Nama pembeli" name="pembeli"  ="">
            </div>
            <div class="mb-3">
                <label class="form-label">Alamat</label>
                <textarea class="form-control" rows="2" placeholder="Alamat" name="alamat" ></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Phone</label>
                <input type="text" class="form-control" placeholder="Nama pembeli" name="phone"  ="">
            </div>
            <div class="mb-3">
                <label class="form-label">Catatan</label>
                <textarea class="form-control" rows="2" placeholder="Alamat" name="catatan" ></textarea>
            </div>
        </div>

        <!-- RIGHT -->
        <div class="col-md-4">
            <div class="mb-3">
                <label class="form-label">No Nota</label>
                <input type="text" class="form-control" value="-" name="nota" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Event</label>
                <input type="text" class="form-control" placeholder="Event" name="event" >
            </div>
            <div class="mb-3">
                <label class="form-label">Grosir</label>
                <input type="text" class="form-control" placeholder="Event" name="grosir" >
            </div>
            <div class="mb-3">
                <label class="form-label">Sub Grosir</label>
                <input type="text" class="form-control" placeholder="Event" name="sub_grosir" >
            </div>
            <div class="mb-3">
                <label class="form-label">Tempat</label>
                <input class="form-control" rows="2" placeholder="Tempat"  name="tempat" >
            </div>
            <div class="mb-3">
                <label class="form-label">Total Berat</label>
                <input class="form-control" rows="2" placeholder="Tempat"  name="total_berat" >
            </div>
        </div>

        <!-- RIGHT -->
        <div class="col-md-4">
            <div class="mb-3">
                <label class="form-label">Kadar</label>
                <input type="text" class="form-control" value="-" name="nota" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label d-block">Harga</label>
                
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="harga[]" value="50000" id="harga1">
                    <label class="form-check-label" for="harga1">Iya</label>
                </div>
                
              
            </div>
          
        </div>
    </div>

    <!-- CARD TAMBAH ITEM -->
    <div class="card mt-4 shadow-sm">
        <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center">
            <h6 class="mb-0 fw-bold">Daftar Item</h6>
            <button type="button" class="btn btn-sm btn-success" id="addRow">
                + Item
            </button>
        </div>
        <div class="card-body p-0">
            <table class="table table-bordered mb-0" id="itemsTable">
                <thead class="table-light">
                    <tr>
                        <th style="width: 120px;">Kategori</th>
                        <th style="width: 150px;">Kadar</th>
                        <th style="width: 150px;">Brt Kotor</th>
                        <th style="width: 150px;">Harga</th>
                        <th style="width: 150px;">Berat Bersih</th>
                        <th style="width: 150px;">Harga Cust</th>
                        <th style="width: 150px;">Brt Bersih Cust</th>
                        <th style="width: 50px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="text" name="category[]" class="form-control" ></td>
                        <td><input type="number" name="cadar[]" class="form-control" min="1" value="1" ></td>
                        <td><input type="number" name="wbruto[]" class="form-control" min="0" step="0.01" ></td>
                        <td><input type="number" name="price[]" class="form-control" min="0" step="0.01" ></td>
                        <td><input type="number" name="wnet[]" class="form-control" min="0" step="0.01" ></td>
                        <td><input type="number" name="pricecust[]" class="form-control" min="0" step="0.01" ></td>
                        <td><input type="number" name="wnetocust[]" class="form-control" min="0" step="0.01" ></td>
                        <td class="text-center">
                            <button type="button" class="btn btn-sm btn-danger removeRow">&times;</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- SUBMIT -->
        <div class="row mt-3">
            <div class="col text-center">
                <button type="submit" class="btn btn-danger fw-bold px-5">Simpan</button>
            </div>
        </div>
</form>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const addRowBtn = document.getElementById("addRow");
        const itemsTable = document.getElementById("itemsTable").getElementsByTagName("tbody")[0];
    
        addRowBtn.addEventListener("click", function() {
            let newRow = document.createElement("tr");
            newRow.innerHTML = `
                <td><input type="text" name="category[]" class="form-control" ></td>
                <td><input type="number" name="cadar[]" class="form-control" min="1" value="1" ></td>
                <td><input type="number" name="wbruto[]" class="form-control" min="0" step="0.01" ></td>
                <td><input type="number" name="price[]" class="form-control" min="0" step="0.01" ></td>
                <td><input type="number" name="wnet[]" class="form-control" min="0" step="0.01" ></td>
                <td><input type="number" name="pricecust[]" class="form-control" min="0" step="0.01" ></td>
                <td><input type="number" name="wnetocust[]" class="form-control" min="0" step="0.01" ></td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-danger removeRow">&times;</button>
                </td>
            `;
            itemsTable.appendChild(newRow);
        });
    
        // remove row
        itemsTable.addEventListener("click", function(e) {
            if (e.target.classList.contains("removeRow")) {
                e.target.closest("tr").remove();
            }
        });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\salespj\resources\views/nota_tagihan.blade.php ENDPATH**/ ?>